import math

A = -10
B = 5.5
C = 4 + 6j

#Absolute Value
print(math.fabs(A))
# e^x
print(math.exp(B))
# Natural Log
print(math.log(1))
#Base Ten log
print(math.log10(1000))
#Sqrt
print(math.sqrt(4))

ListA = [10,20,30]
print(max(ListA))
print(min(ListA))

print(math.cos(1))
print(math.sin(1))
print(math.tan(1))
print(math.hypot(3,4))

print(math.degrees(math.sin(1)))
