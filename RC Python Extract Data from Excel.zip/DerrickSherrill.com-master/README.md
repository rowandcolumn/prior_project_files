# DerrickSherrill.com

This is a code repository that stores various code examples for my website and youtube videos.

Most of the time I'll add Python scripts to this repo that are independent of each other. More or less a collection of (Hopefully) useful tools. 

Check out My YouTube Channel!
https://www.youtube.com/channel/UCJHs6RO1CSM85e8jIMmCySw?view_as=subscriber
